

package org.example;

import com.google.common.collect.ImmutableMap;
import io.appium.java_client.MobileBy;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.Activity;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.net.MalformedURLException;
import java.time.Duration;

import static org.junit.Assert.assertTrue;

public class TestTEST {

    private AndroidDriver driver;

    @Before
    public void setUp() throws MalformedURLException {
        driver = SetupTest.initializeDriver();
    }


    @Test
    public void addReminderTest() {
        System.out.println("Starting addReminderTest...");
        try {
            driver.startActivity(new Activity("com.samsung.android.app.reminder", ".ui.LaunchMainActivity"));

            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));

            WebElement addButton = wait.until(ExpectedConditions.elementToBeClickable(
                    By.id("com.samsung.android.app.reminder:id/floating_action_button")));
            addButton.click();

            WebElement titleInput = wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.id("com.samsung.android.app.reminder:id/add_viewholder_text_view")));
            titleInput.sendKeys("To Do");


            try {
                WebElement saveButton = wait.until(ExpectedConditions.elementToBeClickable(
                        By.id("com.samsung.android.app.reminder:id/action_save_reminder")));
                saveButton.click();
            } catch (Exception e) {
                System.out.println("Standard Save button failed. Trying fallback...");
                WebElement saveFallback = wait.until(ExpectedConditions.presenceOfElementLocated(
                        By.xpath("//android.widget.Button[@content-desc='Save']")));
                String elementId = ((RemoteWebElement) saveFallback).getId();
                driver.executeScript("mobile: clickGesture", ImmutableMap.of("elementId", elementId));
            }

            System.out.println("Test passed: Reminder added successfully (without time).");

        } catch (Exception e) {
            e.printStackTrace();
            assertTrue("Test failed due to exception: " + e.getMessage(), false);
        }
    }

    @After
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}


