package org.example;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import junit.framework.TestCase;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;

import java.net.MalformedURLException;
import java.net.URL;


public class AppTest 
    extends TestCase {

    private AndroidDriver driver;

    @Before
    public void setUp() throws MalformedURLException {
        UiAutomator2Options options = new UiAutomator2Options();
        options.setPlatformName("Android");
        options.setPlatformVersion("13");
        options.setDeviceName("Galaxy A23 5G");
        options.setAutomationName("UiAutomator2");
        options.setAppPackage("com.samsung.android.app.reminder");
        options.setAppActivity(".ui.LaunchMainActivity");
        options.setNoReset(true);
        driver = new AndroidDriver(new URL("http://127.0.0.1:4723"), options);
    }

    @Test
    public void addReminderTest() {
        try {
            System.out.println("Opening Reminder App...");

            driver.findElement(By.id("com.samsung.android.app.reminder:id/floating_action_button")).click();

        }catch (Exception e) {
            e.printStackTrace();
            assert false : "Reminder not added successfully.";
        }
    }


    @After
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
